SFML Game Development Book Examples
===================================

This directory contains an Object Pascal port of the examples from the "SFML Game Development" book. The book is aimed for C++ developers, but can be used for Object Pascal developers as well as the OOP layers are similar.

You can obtain the book at 
https://www.packtpub.com/game-development/sfml-game-development

The original examples are available here:
https://github.com/SFML/SFML-Game-Development-Book

The license applies to the original and to the Pascal port. However, this Pascal port is not the original source code nor related other than that it's a port.